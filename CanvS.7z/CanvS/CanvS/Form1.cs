﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace CanvS
{
    public partial class Form1 : Form
    {

        Graphics g;
        public Form1()
        {
            InitializeComponent();
            g = Graphics.FromHwnd(this.Handle);  // холст
            // сглаживание: enum SmoothingMode 
            g.SmoothingMode = SmoothingMode.AntiAlias;
        }


        private void button1_Click(object sender, EventArgs e)
        {
            g.Clear(BackColor);
        }

        private Point[] star5(int x, int y, int r)  // звезда
        {
            Point point1 = new Point(x, y - 6 * r);
            Point point2 = new Point(x + 2 * r, y - 3 * r);
            Point point3 = new Point(x + 6 * r, y - 2 * r);
            Point point4 = new Point(x + 3 * r, y + r);
            Point point5 = new Point(x + 4 * r, y + 5 * r);
            Point point6 = new Point(x, y + 3 * r);
            Point point7 = new Point(x - 4 * r, y + 5 * r);
            Point point8 = new Point(x - 3 * r, y + r);
            Point point9 = new Point(x - 6 * r, y - 2 * r);
            Point point10 = new Point(x - 2 * r, y - 3 * r);
            Point point11 = new Point(x, y - 6 * r);
            Point[] pm =
            {
             point1,
             point2,
             point3,
             point4,
             point5,
             point6,
             point7,
             point8,
             point9,
             point10,
             point11
         };
            return pm;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Pen redPen = new Pen(Color.Red, 2f);
            // Задание 10 точек, определяющих незамкнутую ломаную
            Point[] pm = star5(200, 200, 25);
            // Рисование незамкнутой ломаной из отрезков (Line)
            g.DrawLines(redPen, pm); // для замыкания добавьте первую точку
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Pen greenPen = new Pen(Color.Green, 2f);
            // Задание 10 точек, определяющих замкнутую область "звезда"
            Point[] pm = star5(250, 220, 25);
            // Рисование замкнутой ломаной из отрезков
            g.DrawClosedCurve(greenPen, pm, 0f, FillMode.Winding);
            // Упругость: 0f - беск.физ.упругость - прямыми;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            // Зададим точки для 2-х кривых Безье - всего 7.
            Point start = new Point(500, 100);
            Point control1 = new Point(750, 50);
            Point control2 = new Point(510, 310);
            Point end1 = new Point(500, 300);
            Point control3 = new Point(490, 310);
            Point control4 = new Point(240, 50);
            Point end2 = new Point(490, 100);
            Point[] bezierPoints =
            {
            start, control1, control2, end1, control3, control4, end2
         };
            // Рисуем
            g.DrawBeziers(new Pen(Color.Red, 3), bezierPoints);
        }
    }
}
