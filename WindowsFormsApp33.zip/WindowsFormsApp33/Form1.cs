﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp33
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            trackBar1.Value = 3;
            pictureBox1.Image = null;
            label7.Text = null;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double r = double.Parse(textBox1.Text);
            double v = double.Parse(textBox2.Text);
            double i = v / ((r / 100) * (r / 100));
            label7.Text = i.ToString("##.##");
            if (radioButton1.Checked)
            {
                if (i < 18)
                {
                    trackBar1.Value = 1;
                    pictureBox1.Image = Image.FromFile(@"C:\Users\student\Documents\Pahomov\WindowsFormsApp33\img\bmi-underweight-icon.png");
                    label11.Text = "Недостаточный";
                }

                else if (i < 26)
                {
                    trackBar1.Value = 3;
                    pictureBox1.Image = Image.FromFile(@"C:\Users\student\Documents\Pahomov\WindowsFormsApp33\img\bmi-healthy-icon.png");
                    label11.Text = "Здоровый";
                }

                else if (i < 35)
                {
                    trackBar1.Value = 5;
                    pictureBox1.Image = Image.FromFile(@"C:\Users\student\Documents\Pahomov\WindowsFormsApp33\img\bmi-overweight-icon.png");
                    label11.Text = "Избыточный";
                }

                else
                {
                    trackBar1.Value = 7;
                    pictureBox1.Image = Image.FromFile(@"C:\Users\student\Documents\Pahomov\WindowsFormsApp33\img\bmi-obese-icon.png");
                    label11.Text = "Ожирение";
                }
            }
            
            if (radioButton2.Checked) {

                if (i < 18)
                {
                    trackBar1.Value = 1;
                    pictureBox1.Image = Image.FromFile(@"C:\Users\student\Documents\Pahomov\WindowsFormsApp33\img\bmi-underweight-iconw.png");
                    label11.Text = "Недостаточный";
                }

                else if (i < 26)
                {
                    trackBar1.Value = 3;
                    pictureBox1.Image = Image.FromFile(@"C:\Users\student\Documents\Pahomov\WindowsFormsApp33\img\bmi-healthy-iconw.png");
                    label11.Text = "Здоровый";
                }

                else if (i < 35)
                {
                    trackBar1.Value = 5;
                    pictureBox1.Image = Image.FromFile(@"C:\Users\student\Documents\Pahomov\WindowsFormsApp33\img\bmi-overweight-iconw.png");
                    label11.Text = "Избыточный";
                }

                else
                {
                    trackBar1.Value = 7;
                    pictureBox1.Image = Image.FromFile(@"C:\Users\student\Documents\Pahomov\WindowsFormsApp33\img\bmi-obese-iconw.png");
                    label11.Text = "Ожирение";
                }
            }
            
        }

       
    }
}
