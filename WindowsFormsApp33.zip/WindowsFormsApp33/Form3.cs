﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp33
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();

            DateTime vremya = new DateTime(2021, 12, 31, 23,59,59);
            int m = vremya.Month - DateTime.Now.Month;
            int d = vremya.Day - DateTime.Now.Day;
            int h = vremya.Hour - DateTime.Now.Hour;
            int min = vremya.Minute - DateTime.Now.Minute;
            int s = vremya.Second - DateTime.Now.Second;

            string mes = " месяц ";
            string dney = " день ";
            string chasov = " час ";
            string minut = " минута ";
            string secund = " секунда";

            if ((m % 10)> 1 && (m % 10) < 5)
            {
                mes = " месяца ";
            }
            if ((m % 10 == 0) | (m % 10 == 6) | (m % 10 == 7) | (m % 10 == 8) | (m % 10 == 9))
            {
                mes = " месяцев ";
            }

            if (m > 9 && m < 21)
            {
                mes = " месяцев ";
            }

            if ((d % 10) > 1 && (d % 10) < 5)
            {
                dney = " дня ";
            }
            if ((d % 10 == 0) | (d % 10 == 6) | (d % 10 == 7) | (d % 10 == 8) | (d % 10 == 9))
            {
                dney = " дней ";
            }

            if (d > 9 && d < 21)
            {
                dney = " дней ";
            }

            if ((h % 10) > 1 && (h % 10) < 5)
            {
                chasov = " часа ";
            }
            if ((h % 10 == 0) | (h % 10 == 6) | (h % 10 == 7) | (h % 10 == 8) | (h % 10 == 9))
            {
                chasov = " часов ";
            }

            if (h > 9 && h < 21)
            {
                chasov = " часов ";
            }

            if ((min % 10) > 1 && (min % 10) < 5)
            {
                minut = " минуты ";
            }

            if ((min % 10 == 0) | (min % 10 == 6) | (min % 10 == 7) | (min % 10 == 8) | (min % 10 == 9))
            {
                minut = " минут ";
            }

            if (min > 9 && min < 21)
            {
                minut = " минут ";
            }

            if ((s%10) > 1 && (s%10) < 5)
            {
                secund = " секунды";
            }

            if ((s % 10 == 0) | (s % 10 == 6) | (s % 10 == 7) | (s % 10 == 8) | (s % 10 == 9)) {
                secund = " секунд";
            }
                
            if (s > 9 && s < 21)
            {
                secund = " секунд";
            }

            Convert.ToString(m);
            Convert.ToString(d);
            Convert.ToString(h);
            Convert.ToString(min);
            Convert.ToString(s);

            label2.Text = m + mes + d + dney + h + chasov + min + minut + s + secund;
        }
    }
}
