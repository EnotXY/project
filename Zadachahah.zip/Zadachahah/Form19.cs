﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zadachahah
{
    public partial class Form19 : Form
    {
        public Form19()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            pictureBox1.Width = Convert.ToInt32(textBox1.Text) / 5;
            pictureBox1.Height = Convert.ToInt32(textBox2.Text) / 5;
            int sum = (Convert.ToInt32(textBox1.Text) / 5) * (Convert.ToInt32(textBox2.Text) / 5);

            if (checkBox1.Checked)
            {
                pictureBox1.Image = Image.FromFile(@"C:\Users\student\Documents\Pahomov\oknofix.png");
                if (comboBox1.SelectedIndex == 0)
                {
                    sum += 1500;
                }

                else
                {
                    sum += 2000;
                }
            }

            if (checkBox2.Checked)
            {
                pictureBox1.Image = Image.FromFile(@"C:\Users\student\Documents\Pahomov\oknoset.png");
                if (comboBox1.SelectedIndex == 0)
                {
                    sum += 2200;
                }

                else
                {
                    sum += 3000;
                }
            }

            if (checkBox3.Checked)
            {
                pictureBox1.Image = Image.FromFile(@"C:\Users\student\Documents\Pahomov\oknoveter.png");
                if (comboBox1.SelectedIndex == 0)
                {
                    sum += 3000;
                }

                else
                {
                    sum += 4000;
                }
            }

            textBox3.Text = Convert.ToString(sum);
        }
    }
}
