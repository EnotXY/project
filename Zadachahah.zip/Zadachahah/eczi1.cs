﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zadachahah
{
    public partial class eczi1 : Form
    {
        public eczi1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                pictureBox1.Image = Image.FromFile(@"C:\Users\student\Documents\Pahomov\gov.png");
                label2.Text = ("300000");
            }

            if (radioButton2.Checked)
            {
                pictureBox1.Image = Image.FromFile(@"C:\Users\student\Documents\Pahomov\kom.png");
                label2.Text = ("500000");
            }

            if (radioButton3.Checked)
            {
                pictureBox1.Image = Image.FromFile(@"C:\Users\student\Documents\Pahomov\prem.png");
                label2.Text = ("700000");
            }
        }
    }
}
