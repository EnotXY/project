﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Zadachahah
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string textSum = textBox1.Text;
            int znachSum = Convert.ToInt32(textSum);

            string textMesya = textBox2.Text;
            int znachMesya = Convert.ToInt32(textMesya);
            int celmes = znachMesya / 12;

            string textProc = textBox3.Text;
            int znachProc = Convert.ToInt32(textProc);

            int znachItog = znachSum + znachSum * celmes * znachProc/100;
            textBox4.Text = Convert.ToString(znachItog);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
