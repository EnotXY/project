﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zadachahah
{
    public partial class Zadacha11 : Form
    {
        public Zadacha11()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0)
            {
                textBox3.Text = "LUCHSHIE, KOMPUTERNIYE SETI";
            }

            else if (comboBox1.SelectedIndex == 1)
            {
                textBox3.Text = "Informationniye sistemi";
            }

            else if (comboBox1.SelectedIndex == 2)
            {
                textBox3.Text = "Природо хозяйственный чо-тотам комплекс";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form Form15 = new Form15();
            Form15.Show();
        }
    }
}
