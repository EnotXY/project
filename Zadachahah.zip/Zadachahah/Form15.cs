﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zadachahah
{
    public partial class Form15 : Form
    {
        public Form15()
        {
            InitializeComponent();
        }
        int i = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {

           
            i = i + 1;
            label2.Text = "aboba" + i;
            label2.Visible = true;
           

            if (i == 2)
            {
              
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form angl = new angl();
            angl.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form philo = new philo();
            philo.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form russkiy = new russkiy();
            russkiy.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form teoriya = new teoriya();
            teoriya.Show();
        }
    }
}
