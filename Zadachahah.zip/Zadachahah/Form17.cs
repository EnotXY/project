﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zadachahah
{
    public partial class Form17 : Form
    {
        public Form17()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (listBox1.SelectedIndex == 0)
            textBox2.Text = Convert.ToString((Convert.ToInt32(textBox1.Text) - 1) * 300);

            if (listBox1.SelectedIndex == 1)
                textBox2.Text = Convert.ToString((Convert.ToInt32(textBox1.Text) - 1) * 200);

            if (listBox1.SelectedIndex == 2)
                textBox2.Text = Convert.ToString((Convert.ToInt32(textBox1.Text) - 1) * 100);
        }
    }
}
