﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zadachahah
{
    public partial class Form18 : Form
    {
        public Form18()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0)
            {
                textBox2.Text = Convert.ToString(Convert.ToInt32(textBox1.Text) * 100);
            }

            if (comboBox1.SelectedIndex == 1)
            {
                textBox2.Text = Convert.ToString(Convert.ToInt32(textBox1.Text) * 500);
            }

            if (comboBox1.SelectedIndex == 2)
            {
                textBox2.Text = Convert.ToString(Convert.ToInt32(textBox1.Text) * 1000);
            }
        }
    }
}
