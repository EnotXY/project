﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Summa
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {int summa = Convert.ToInt32(textBox1.Text);
             if (radioButton1.Checked)
            { int b = summa * 500;
                label3.Text = Convert.ToString(b);
            }
            if (radioButton2.Checked)
            { int b = summa * 100; 
                label3.Text = Convert.ToString(b); }
            
        }
    }
}
